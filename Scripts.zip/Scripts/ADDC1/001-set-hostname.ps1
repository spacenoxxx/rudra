# Get the network adapter with InterfaceDescription containing "VirtIO"
$adapter = Get-NetAdapter | Where-Object {$_.InterfaceDescription -like "*VirtIO*"}

# Set a static IP address and gateway
$ipAddress = "192.168.101.2"
$subnetMask = "255.255.255.0"
$gateway = "192.168.101.1"

# Remove any existing IP addresses and set the new one
$adapter | Remove-NetIPAddress -Confirm:$false
New-NetIPAddress -InterfaceIndex $adapter.ifIndex -IPAddress $ipAddress -PrefixLength 24

# Remove any existing default gateways and set the new one
$adapter | Remove-NetRoute -Confirm:$false
New-NetRoute -InterfaceIndex $adapter.ifIndex -DestinationPrefix "0.0.0.0/0" -NextHop $gateway

# Set Hostname
Rename-Computer -NewName "ADDC1" -Restart


