$Password = ConvertTo-SecureString "!QAZ2wsx" -AsPlainText -Force
$UserAccount = Get-LocalUser -Name "Administrator"
$userAccount | Set-LocalUser -Password $Password